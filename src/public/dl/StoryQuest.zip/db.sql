-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 18 juin 2022 à 22:57
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_lo07`
--
CREATE DATABASE IF NOT EXISTS `projet_lo07` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `projet_lo07`;

-- --------------------------------------------------------

--
-- Structure de la table `connexion_logs`
--

CREATE TABLE `connexion_logs` (
  `id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `utilisateur_IdUtilisateur` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `histoire`
--

CREATE TABLE `histoire` (
  `id` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `choix1_text` varchar(45) DEFAULT NULL,
  `choix1_id` int(11) DEFAULT NULL,
  `choix2_text` varchar(45) DEFAULT NULL,
  `choix2_id` int(11) DEFAULT NULL,
  `histoire_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `histoire`
--

INSERT INTO `histoire` (`id`, `text`, `choix1_text`, `choix1_id`, `choix2_text`, `choix2_id`, `histoire_type_id`) VALUES
(2, 'Vous entrez dans le donjon', 'Porte de gauche', 4, 'Porte de droite', 7, 1),
(3, 'Vous sortez du donjon', NULL, NULL, NULL, NULL, 1),
(4, 'Retrouve devant un coffre', 'Combattre !', 5, 'Fuir', 6, 1),
(5, 'Vous êtes mort', NULL, NULL, NULL, NULL, 1),
(6, 'Le dragon vous poursuis', 'Prendre une porte', 7, 'Sauter dans un trou', 3, 1),
(7, 'Retrouve devant un coffre', 'Ouvrir', 5, 'Passer son chemin', 3, 1);

-- --------------------------------------------------------

--
-- Structure de la table `histoire_type`
--

CREATE TABLE `histoire_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `histoire_start_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `histoire_type`
--

INSERT INTO `histoire_type` (`id`, `name`, `histoire_start_id`) VALUES
(1, 'Donjon', 2);

-- --------------------------------------------------------

--
-- Structure de la table `jeu`
--

CREATE TABLE `jeu` (
  `IdJeu` bigint(20) NOT NULL,
  `DateCommencer` datetime NOT NULL,
  `DateTerminer` datetime DEFAULT NULL,
  `IdUtilisateur` bigint(20) NOT NULL,
  `histoire_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `perms`
--

CREATE TABLE `perms` (
  `tag` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `perms`
--

INSERT INTO `perms` (`tag`) VALUES
('admin'),
('modo'),
('player');

-- --------------------------------------------------------

--
-- Structure de la table `permsgroup`
--

CREATE TABLE `permsgroup` (
  `tag` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `permsgroup`
--

INSERT INTO `permsgroup` (`tag`, `name`) VALUES
('admin', 'Administrateur'),
('modo', 'Modérateur'),
('player', 'Joueur');

-- --------------------------------------------------------

--
-- Structure de la table `permsgroup_has_perms`
--

CREATE TABLE `permsgroup_has_perms` (
  `permsgroup_tag` varchar(45) NOT NULL,
  `perms_tag` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `permsgroup_has_perms`
--

INSERT INTO `permsgroup_has_perms` (`permsgroup_tag`, `perms_tag`) VALUES
('admin', 'admin'),
('admin', 'modo'),
('admin', 'player'),
('modo', 'modo'),
('modo', 'player'),
('player', 'player');

-- --------------------------------------------------------

--
-- Structure de la table `play_logs`
--

CREATE TABLE `play_logs` (
  `id` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `jeu_IdJeu` bigint(20) NOT NULL,
  `histoire_id` int(11) NOT NULL,
  `choix_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `IdUtilisateur` bigint(20) NOT NULL,
  `Nom` varchar(100) NOT NULL,
  `Prenom` varchar(100) NOT NULL,
  `Pseudo` varchar(10) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `permsgroup_tag` varchar(45) NOT NULL DEFAULT 'player',
  `create_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`IdUtilisateur`, `Nom`, `Prenom`, `Pseudo`, `Password`, `permsgroup_tag`, `create_time`) VALUES
(2, 'admin', '', 'admin', '$2y$10$s/tFLJOtKs6QMTLxp.s6suY0oJnrDz.5uMcNbzsCVhJUDGqMWJvdS', 'admin', '2022-06-14 19:49:02');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `connexion_logs`
--
ALTER TABLE `connexion_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_logs_utilisateur1_idx` (`utilisateur_IdUtilisateur`);

--
-- Index pour la table `histoire`
--
ALTER TABLE `histoire`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_histoire_histoire1_idx` (`choix1_id`),
  ADD KEY `fk_histoire_histoire2_idx` (`choix2_id`),
  ADD KEY `fk_histoire_histoire_type1_idx` (`histoire_type_id`);

--
-- Index pour la table `histoire_type`
--
ALTER TABLE `histoire_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`),
  ADD KEY `fk_histoire_type_histoire1_idx` (`histoire_start_id`);

--
-- Index pour la table `jeu`
--
ALTER TABLE `jeu`
  ADD PRIMARY KEY (`IdJeu`),
  ADD KEY `fk_jeu_utilisateur1` (`IdUtilisateur`),
  ADD KEY `fk_jeu_histoire_type1_idx` (`histoire_type_id`);

--
-- Index pour la table `perms`
--
ALTER TABLE `perms`
  ADD PRIMARY KEY (`tag`);

--
-- Index pour la table `permsgroup`
--
ALTER TABLE `permsgroup`
  ADD PRIMARY KEY (`tag`);

--
-- Index pour la table `permsgroup_has_perms`
--
ALTER TABLE `permsgroup_has_perms`
  ADD PRIMARY KEY (`permsgroup_tag`,`perms_tag`),
  ADD KEY `fk_permsgroup_has_perms_perms1_idx` (`perms_tag`),
  ADD KEY `fk_permsgroup_has_perms_permsgroup1_idx` (`permsgroup_tag`);

--
-- Index pour la table `play_logs`
--
ALTER TABLE `play_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_play_logs_histoire1_idx` (`histoire_id`),
  ADD KEY `fk_play_logs_jeu1_idx` (`jeu_IdJeu`),
  ADD KEY `fk_play_logs_histoire2_idx` (`choix_id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`IdUtilisateur`,`permsgroup_tag`),
  ADD KEY `fk_utilisateur_permsgroup1_idx` (`permsgroup_tag`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `connexion_logs`
--
ALTER TABLE `connexion_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `histoire`
--
ALTER TABLE `histoire`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `histoire_type`
--
ALTER TABLE `histoire_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `jeu`
--
ALTER TABLE `jeu`
  MODIFY `IdJeu` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT pour la table `play_logs`
--
ALTER TABLE `play_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `IdUtilisateur` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `connexion_logs`
--
ALTER TABLE `connexion_logs`
  ADD CONSTRAINT `fk_logs_utilisateur1` FOREIGN KEY (`utilisateur_IdUtilisateur`) REFERENCES `utilisateur` (`IdUtilisateur`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `histoire`
--
ALTER TABLE `histoire`
  ADD CONSTRAINT `fk_histoire_histoire1` FOREIGN KEY (`choix1_id`) REFERENCES `histoire` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_histoire_histoire2` FOREIGN KEY (`choix2_id`) REFERENCES `histoire` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_histoire_histoire_type1` FOREIGN KEY (`histoire_type_id`) REFERENCES `histoire_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `histoire_type`
--
ALTER TABLE `histoire_type`
  ADD CONSTRAINT `fk_histoire_type_histoire1` FOREIGN KEY (`histoire_start_id`) REFERENCES `histoire` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `jeu`
--
ALTER TABLE `jeu`
  ADD CONSTRAINT `fk_jeu_histoire_type1` FOREIGN KEY (`histoire_type_id`) REFERENCES `histoire_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_jeu_utilisateur1` FOREIGN KEY (`IdUtilisateur`) REFERENCES `utilisateur` (`IdUtilisateur`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `permsgroup_has_perms`
--
ALTER TABLE `permsgroup_has_perms`
  ADD CONSTRAINT `fk_permsgroup_has_perms_perms1` FOREIGN KEY (`perms_tag`) REFERENCES `perms` (`tag`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_permsgroup_has_perms_permsgroup1` FOREIGN KEY (`permsgroup_tag`) REFERENCES `permsgroup` (`tag`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `play_logs`
--
ALTER TABLE `play_logs`
  ADD CONSTRAINT `fk_play_logs_histoire1` FOREIGN KEY (`histoire_id`) REFERENCES `histoire` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_play_logs_histoire2` FOREIGN KEY (`choix_id`) REFERENCES `histoire` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_play_logs_jeu1` FOREIGN KEY (`jeu_IdJeu`) REFERENCES `jeu` (`IdJeu`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `fk_utilisateur_permsgroup1` FOREIGN KEY (`permsgroup_tag`) REFERENCES `permsgroup` (`tag`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
