<?php
$logs = false;

$logs_message = "";
$logs_message_erreur = "";

// **********************************************
// Traitement du formulaire                    
// La variable $message contiendra les messages de l'application à afficher
$message = "";

// La variable $message_erreur contiendra les éventuels messages d'erreur de l'application à afficher
$message_erreur = "";
?>