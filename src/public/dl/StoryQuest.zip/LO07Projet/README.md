# LO07Projet
Story Quest
Pierre Bayle
Kléden Rousseau
Chi Nguyen Tran

Compte de l'administrateur: 
Pseudo : admin
Mdp: adminadmin

Installation :
- Lancer XAMPP
- Start les services Apache et MySQL
- Lancer la page admin de service MySQL
- Importer le fichier "db.sql"
- Ouvrir le projet dans le dossier LO07Projet"" dans NetBeans
- Se connecter par le compte admin ou s'incrire un nouveau compte
